package net.javaguides.springboot.model;

public class EmployeeDetailsDAO {
    private Long Mo_number;
    private Integer Age;
    private  Long Salary;
    private String Gender;
    private Long id;
	public Long getMo_number() {
		return Mo_number;
	}
	public void setMo_number(Long mo_number) {
		Mo_number = mo_number;
	}
	public Integer getAge() {
		return Age;
	}
	public void setAge(Integer age) {
		Age = age;
	}
	public Long getSalary() {
		return Salary;
	}
	public void setSalary(Long salary) {
		Salary = salary;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public EmployeeDetailsDAO(Long mo_number, Integer age, Long salary, String gender, Long id) {
		super();
		Mo_number = mo_number;
		Age = age;
		Salary = salary;
		Gender = gender;
		this.id = id;
	}
	public EmployeeDetailsDAO() {
		super();
	
	}
    
    
}
