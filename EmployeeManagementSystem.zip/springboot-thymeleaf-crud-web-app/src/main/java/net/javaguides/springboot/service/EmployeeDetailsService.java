package net.javaguides.springboot.service;


import net.javaguides.springboot.model.Employeedetails;

public interface EmployeeDetailsService {

	 void saveEmployeeDetails(Employeedetails employeedetails);
}
