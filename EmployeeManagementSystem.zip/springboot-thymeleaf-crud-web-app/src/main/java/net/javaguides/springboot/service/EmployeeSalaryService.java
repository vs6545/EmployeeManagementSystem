package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Salary;

public interface EmployeeSalaryService {

	void saveEmployeeSalary (Salary salary);
}
