package net.javaguides.springboot.service;

import java.io.IOException;
import java.util.List;

import org.springframework.data.domain.Page;

import jakarta.servlet.http.HttpServletResponse;
import net.javaguides.springboot.model.Employee;

public interface EmployeeService {
   List<Employee> getAllEmployees(String keyword);
   void saveEmployee(Employee employee);
   
   Employee getEmployeeById(long id);
   
  void deleteEmployeeById(long id);
  
  Page<Employee> findpaginated(int pageNo,int pageSize);
  
   default void generateExcel(HttpServletResponse response) throws IOException {
	  
  }
   

}