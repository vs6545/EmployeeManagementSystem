package net.javaguides.springboot.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;


@Entity
@Table (name = "Employeedetails")
public class Employeedetails {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
	
    @Column(name = "Dep_id")
	private long DepartmentID;
	
	@Column(name = "Mo_number")
    private Long Mo_number;
	
	public long getDepartmentID() {
		return DepartmentID;
	}

	public void setDepartmentID(long departmentID) {
		DepartmentID = departmentID;
	}

	public Long getMo_number() {
		return Mo_number;
	}

	public void setMo_number(Long mo_number) {
		Mo_number = mo_number;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public Long getSalary() {
		return Salary;
	}

	public void setSalary(Long salary) {
		Salary = salary;
	}

	public Integer getAge() {
		return Age;
	}
	

	
	@Override
	public String toString() {
		return "Employeedetails [DepartmentID=" + DepartmentID + ", Mo_number=" + Mo_number + ", Gender=" + Gender
				+ ", Salary=" + Salary + ", Age=" + Age + "]";
	}

	public void setAge(Integer age) {
		Age = age;
	}
	@JsonBackReference
	@OneToOne
	@JoinColumn(name="employee_id")
	
	
	private Employee employee;

	@Column(name = "Gender")
	private String Gender;
	
	@Column(name = "Salary")
	private  Long Salary;
	
	@Column(name = "Age")
	private Integer Age;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Employeedetails( Long mo_number, Employee employee, String gender, Long salary,
			Integer age) {
		//super();
	
		Mo_number = mo_number;
		this.employee = employee;
		Gender = gender;
		Salary = salary;
		Age = age;
	}

	public Employeedetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
}

