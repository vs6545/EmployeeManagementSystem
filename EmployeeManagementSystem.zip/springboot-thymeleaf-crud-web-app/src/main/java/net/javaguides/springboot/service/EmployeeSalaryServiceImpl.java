package net.javaguides.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.model.Salary;
import net.javaguides.springboot.repository.EmployeeSalaryRepository;

@Service
public class EmployeeSalaryServiceImpl implements EmployeeSalaryService {

	
	@Autowired
	private EmployeeSalaryRepository employeeSalaryRepository;

	@Override
	public void saveEmployeeSalary(Salary salary) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
