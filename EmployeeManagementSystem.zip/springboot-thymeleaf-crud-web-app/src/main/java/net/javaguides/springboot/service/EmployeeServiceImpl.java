package net.javaguides.springboot.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import net.javaguides.springboot.model.Employee;
import net.javaguides.springboot.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	
    @Autowired	
    private EmployeeRepository employeeRepository;
	
	@Override
	public List<Employee> getAllEmployees(String keyword) {
		if (keyword != null) {
			return employeeRepository.findAll(keyword);
		}
		return employeeRepository.findAll();
	}

	@Override
	public void saveEmployee(Employee employee) {
	this.employeeRepository.save(employee);
		
	}

	@Override
	public Employee getEmployeeById(long id) {
		Optional<Employee> optional = employeeRepository.findById(id);
		Employee employee = null;
		if(optional.isPresent()) {
			employee = optional.get();
		}else {
			throw new RuntimeException("Employee not found for id :: " +id);
		}
		return employee;
	}

	@Override
	public void deleteEmployeeById(long id) {
		this.employeeRepository.deleteById(id);
		
	}

	@Override
		public Page<Employee> findpaginated(int pageNo, int pageSize) {
			   Pageable pageable = PageRequest.of(pageNo - 1 , pageSize);
				return this.employeeRepository.findAll(pageable);
	}

	@Override
	public void generateExcel(HttpServletResponse response) throws IOException{
	List<Employee> employees	= employeeRepository.findAll();
		
	HSSFWorkbook workbook = new HSSFWorkbook();
	HSSFSheet sheet = workbook.createSheet("Employee Info");
	HSSFRow row = sheet.createRow(0);
	row.createCell(0).setCellValue("id");
	row.createCell(1).setCellValue(" firstName");
	row.createCell(2).setCellValue("LastName");
	row.createCell(3).setCellValue("email");
	
	int dataRowIndex = 1;
	
	for (Employee employee : employees) {
	
		HSSFRow dataRow = sheet.createRow(dataRowIndex);
		dataRow.createCell(0).setCellValue(employee.getId());
		dataRow.createCell(1).setCellValue(employee.getFirstName());
		dataRow.createCell(2).setCellValue(employee.getLastName());
		dataRow.createCell(3).setCellValue(employee.getEmail());
		
		dataRowIndex ++;
		
	}
	ServletOutputStream ops = response.getOutputStream();
	workbook.write(ops);
	workbook.close();
	ops.close();
	}
}



