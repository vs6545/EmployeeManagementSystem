package net.javaguides.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.model.Employeedetails;
import net.javaguides.springboot.repository.EmployeeDetailsRepository;


@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {

	@Autowired
	private EmployeeDetailsRepository employeeDetailsRepository;
	
	@Override
	public void saveEmployeeDetails(Employeedetails employeedetails) {
		this.employeeDetailsRepository.save(employeedetails);
		
	}

	
	
}
