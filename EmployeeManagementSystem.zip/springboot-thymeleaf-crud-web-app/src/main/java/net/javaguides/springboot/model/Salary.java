package net.javaguides.springboot.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.annotation.Generated;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table (name = "Salary")
public class Salary {
	
	
	
	@JsonBackReference
	@OneToOne
	@JoinColumn(name = "employee_id")
	private Employee employee;
	
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)

    private long salary_id;
	
	@Column(name="ctc")
	private String ctc;
	
	@Column(name="basic_salary")
	private String basicSalary;
	
	@Column(name="house_rent_allowance")
	private String houseRentAllowance;
	
	@Column(name="conveyance_allowance")
	private String conveyanceAllowance;
	
	@Column(name="epf")
	private String epf;
	
	@Column(name="health_insurance")
	private String healthInsurance;
	
	@Column(name="tax_tds")
	private String taxTDS;
	
	@Column(name="net_pay")
	private String netPay;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public long getSalary_id() {
		return salary_id;
	}

	public void setSalary_id(long salary_id) {
		this.salary_id = salary_id;
	}

	public String getCtc() {
		return ctc;
	}

	public void setCtc(String ctc) {
		this.ctc = ctc;
	}

	public String getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(String basicSalary) {
		this.basicSalary = basicSalary;
	}

	public String getHouseRentAllowance() {
		return houseRentAllowance;
	}

	public void setHouseRentAllowance(String houseRentAllowance) {
		this.houseRentAllowance = houseRentAllowance;
	}

	public String getConveyanceAllowance() {
		return conveyanceAllowance;
	}

	public void setConveyanceAllowance(String conveyanceAllowance) {
		this.conveyanceAllowance = conveyanceAllowance;
	}

	public String getEpf() {
		return epf;
	}

	public void setEpf(String epf) {
		this.epf = epf;
	}

	public String getHealthInsurance() {
		return healthInsurance;
	}

	public void setHealthInsurance(String healthInsurance) {
		this.healthInsurance = healthInsurance;
	}

	public String getTaxTDS() {
		return taxTDS;
	}

	public void setTaxTDS(String taxTDS) {
		this.taxTDS = taxTDS;
	}

	public String getNetPay() {
		return netPay;
	}

	public void setNetPay(String netPay) {
		this.netPay = netPay;
	}
	
	
	

	
	

}
